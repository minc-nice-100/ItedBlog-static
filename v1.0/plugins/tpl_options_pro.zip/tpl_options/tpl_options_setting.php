<?php

/*
Plugin Name: 模板设置
Version: 3.3
Plugin URL: https://lanyes.org
Description: 允许为支持的模板设置参数。
ForEmlog: pro
Author: 奇遇 蓝叶
Author URL: https://lanyes.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');

//插件设置页面
function plugin_setting_view() {
	TplOptions::getInstance()->setting();
}

//插件设置函数，不用
function plugin_setting() {
}
